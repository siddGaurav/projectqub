import {
    PieChart,
    Pie,
    Cell,
    Tooltip,
    ResponsiveContainer,
} from "recharts";

const data = [
    { name: "Sales", value: 68 },
    { name: "Product", value: 25 },
    { name: "Income", value: 14 },
];

const COLORS = ["#22c55e", "#3b82f6", "#f59e0b"];

const PieChartComponent = () => {
    return (
        <ResponsiveContainer width="100%" height={300}>
            <PieChart>
                <Pie
                    data={data}
                    innerRadius={70}
                    outerRadius={100}
                    dataKey="value"
                >
                    {data.map((entry, index) => (
                        <Cell key={index} fill={COLORS[index]} />
                    ))}
                </Pie>
                <Tooltip />
            </PieChart>
        </ResponsiveContainer>
    );
};

export default PieChartComponent;