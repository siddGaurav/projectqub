import {
    BarChart,
    Bar,
    XAxis,
    YAxis,
    Tooltip,
    ResponsiveContainer,
} from "recharts";

const data = [
    { name: "Jan", sales: 40, views: 24 },
    { name: "Feb", sales: 30, views: 13 },
    { name: "Mar", sales: 20, views: 98 },
    { name: "Apr", sales: 27, views: 39 },
];

const BarChartComponent = () => {
    return (
        <ResponsiveContainer width="100%" height={300}>
            <BarChart data={data}>
                <XAxis dataKey="name" stroke="#ccc" />
                <YAxis stroke="#ccc" />
                <Tooltip />
                <Bar dataKey="sales" fill="#22c55e" />
                <Bar dataKey="views" fill="#3b82f6" />
            </BarChart>
        </ResponsiveContainer>
    );
};

export default BarChartComponent;