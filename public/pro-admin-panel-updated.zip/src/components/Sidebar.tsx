import {
  LayoutDashboard,
  BarChart3,
  Boxes,
  AppWindow,
  Layers,
  ShoppingCart,
  FileText,
  Table,
  User,
} from "lucide-react";

import { NavLink } from "react-router-dom";

const Sidebar = () => {
  const linkClass =
    "flex items-center gap-2 cursor-pointer hover:text-green-400";

  const activeClass = "text-green-400";

  return (
    <div className="w-64 bg-black text-white p-5 overflow-y-auto min-h-screen">

      <h2 className="text-2xl font-bold mb-6 text-green-400">Darken</h2>

      {/* MAIN */}
      <p className="text-gray-500 text-xs mb-2">MAIN</p>
      <ul className="space-y-3 mb-6">
        <NavLink to="/" className={({ isActive }) => `${linkClass} ${isActive ? activeClass : ""}`}>
          <LayoutDashboard size={16} /> Dashboard
        </NavLink>

        <NavLink to="/analysis" className={({ isActive }) => `${linkClass} ${isActive ? activeClass : ""}`}>
          <BarChart3 size={16} /> Analysis
        </NavLink>
      </ul>

      {/* APPS */}
      <p className="text-gray-500 text-xs mb-2">APPS</p>
      <ul className="space-y-3 mb-6">
        <NavLink to="/widgets" className={({ isActive }) => `${linkClass} ${isActive ? activeClass : ""}`}>
          <Boxes size={16} /> Widgets
        </NavLink>

        <NavLink to="/apps" className={({ isActive }) => `${linkClass} ${isActive ? activeClass : ""}`}>
          <AppWindow size={16} /> Apps
        </NavLink>
      </ul>

      {/* UI */}
      <p className="text-gray-500 text-xs mb-2">UI ELEMENTS</p>
      <ul className="space-y-3 mb-6">
        <NavLink to="/cards" className={({ isActive }) => `${linkClass} ${isActive ? activeClass : ""}`}>
          <Layers size={16} /> Cards
        </NavLink>

        <NavLink to="/ecommerce" className={({ isActive }) => `${linkClass} ${isActive ? activeClass : ""}`}>
          <ShoppingCart size={16} /> eCommerce
        </NavLink>
      </ul>

      {/* FORMS */}
      <p className="text-gray-500 text-xs mb-2">FORMS & TABLES</p>
      <ul className="space-y-3 mb-6">
        <NavLink to="/forms" className={({ isActive }) => `${linkClass} ${isActive ? activeClass : ""}`}>
          <FileText size={16} /> Forms
        </NavLink>

        <NavLink to="/tables" className={({ isActive }) => `${linkClass} ${isActive ? activeClass : ""}`}>
          <Table size={16} /> Tables
        </NavLink>
      </ul>

      {/* PROFILE */}
      <p className="text-gray-500 text-xs mb-2">PAGES</p>
      <ul className="space-y-3">
        <NavLink to="/profile" className={({ isActive }) => `${linkClass} ${isActive ? activeClass : ""}`}>
          <User size={16} /> Profile
        </NavLink>
      </ul>

    </div>
  );
};

export default Sidebar;