import {
  Users,
  ShoppingCart,
  DollarSign,
  Activity,
} from "lucide-react";
import Chart from "../components/Chart";
import BarChartComponent from "../components/BarChart";
import PieChartComponent from "../components/PieChart";

const Dashboard = () => {
  return (
    <div className="p-6 bg-[#0f172a] min-h-screen text-white">

      {/* 🔹 Top Bar */}
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Dashboard</h1>

        <input
          type="text"
          placeholder="Search..."
          className="bg-[#1e293b] px-3 py-2 rounded-lg outline-none text-sm"
        />
      </div>

      {/* 🔹 Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">

        <div className="bg-[#1e293b] p-5 rounded-xl flex items-center justify-between hover:scale-105 transition">
          <div>
            <p className="text-gray-400 text-sm">Users</p>
            <h2 className="text-xl font-bold">1,240</h2>
          </div>
          <Users className="text-green-400" />
        </div>

        <div className="bg-[#1e293b] p-5 rounded-xl flex items-center justify-between hover:scale-105 transition">
          <div>
            <p className="text-gray-400 text-sm">Orders</p>
            <h2 className="text-xl font-bold">320</h2>
          </div>
          <ShoppingCart className="text-blue-400" />
        </div>

        <div className="bg-[#1e293b] p-5 rounded-xl flex items-center justify-between hover:scale-105 transition">
          <div>
            <p className="text-gray-400 text-sm">Revenue</p>
            <h2 className="text-xl font-bold">$12,500</h2>
          </div>
          <DollarSign className="text-yellow-400" />
        </div>

        <div className="bg-[#1e293b] p-5 rounded-xl flex items-center justify-between hover:scale-105 transition">
          <div>
            <p className="text-gray-400 text-sm">Active</p>
            <h2 className="text-xl font-bold">98%</h2>
          </div>
          <Activity className="text-red-400" />
        </div>

      </div>

      {/* 🔥 Chart Section (NEW) */}
      <div className="mt-8 bg-[#1e293b] p-5 rounded-xl shadow-lg">
        <h2 className="text-lg font-semibold mb-4">Sales Overview</h2>
        <Chart />
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">

        <div className="bg-[#1e293b] p-5 rounded-xl">
          <h2 className="mb-4">Sales & Views</h2>
          <BarChartComponent />
        </div>

        <div className="bg-[#1e293b] p-5 rounded-xl">
          <h2 className="mb-4">Order Status</h2>
          <PieChartComponent />
        </div>

      </div>

      {/* 🔹 Table */}
      <div className="mt-8 bg-[#1e293b] p-5 rounded-xl shadow-lg">
        <h2 className="text-lg font-semibold mb-4">Recent Users</h2>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="text-gray-400 border-b border-gray-700">
                <th className="py-3">Name</th>
                <th>Email</th>
                <th>Status</th>
              </tr>
            </thead>

            <tbody>
              <tr className="border-b border-gray-800 hover:bg-[#334155] transition">
                <td className="py-3">Rakesh</td>
                <td>rakesh@gmail.com</td>
                <td className="text-green-400 font-semibold">Active</td>
              </tr>

              <tr className="border-b border-gray-800 hover:bg-[#334155] transition">
                <td className="py-3">Amit</td>
                <td>amit@gmail.com</td>
                <td className="text-yellow-400 font-semibold">Pending</td>
              </tr>

              <tr className="hover:bg-[#334155] transition">
                <td className="py-3">Rahul</td>
                <td>rahul@gmail.com</td>
                <td className="text-red-400 font-semibold">Blocked</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};

export default Dashboard;