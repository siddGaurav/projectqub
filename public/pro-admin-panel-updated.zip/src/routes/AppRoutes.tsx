
import { BrowserRouter, Routes, Route } from "react-router-dom";
import AdminLayout from "../layouts/AdminLayout";
import Dashboard from "../pages/Dashboard";
import Analysis from "../pages/Analysis";
import Widgets from "../pages/Widgets";
import Apps from "../pages/Apps";
import CardsPage from "../pages/CardsPage";
import Ecommerce from "../pages/Ecommerce";
import Forms from "../pages/Forms";
import Tables from "../pages/Tables";
import Profile from "../pages/Profile";

export default function AppRoutes(){
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<AdminLayout/>}>
          <Route index element={<Dashboard/>}/>
          <Route path="analysis" element={<Analysis/>}/>
          <Route path="widgets" element={<Widgets/>}/>
          <Route path="apps" element={<Apps/>}/>
          <Route path="cards" element={<CardsPage/>}/>
          <Route path="ecommerce" element={<Ecommerce/>}/>
          <Route path="forms" element={<Forms/>}/>
          <Route path="tables" element={<Tables/>}/>
          <Route path="profile" element={<Profile/>}/>
        </Route>
      </Routes>
    </BrowserRouter>
  )
}
