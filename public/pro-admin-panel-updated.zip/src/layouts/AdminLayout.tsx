import Sidebar from "../components/Sidebar";
import { Outlet } from "react-router-dom";

const AdminLayout = () => {
  return (
    <div className="flex">
      <Sidebar />

      {/* 👇 yaha dashboard show hoga */}
      <div className="flex-1 bg-[#0f172a] min-h-screen">
        <Outlet />
      </div>
    </div>
  );
};

export default AdminLayout;